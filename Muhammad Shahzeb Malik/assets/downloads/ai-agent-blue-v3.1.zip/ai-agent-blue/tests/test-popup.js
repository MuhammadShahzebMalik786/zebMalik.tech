// popup.js integration test via jsdom: load popup.html + popup.js, drive the UI.
const fs = require('fs');
const { JSDOM } = require('jsdom');

const html = fs.readFileSync(require('path').join(__dirname,'..','popup.html'), 'utf8');
const js = fs.readFileSync(require('path').join(__dirname,'..','popup.js'), 'utf8');

let pass = 0, fail = 0;
const ok = (n, c) => { console.log((c ? 'PASS ' : 'FAIL ') + n); c ? pass++ : fail++; };

const store = {};
const sentToBg = [];
let bgListener = null;

const dom = new JSDOM(html, { url: 'chrome-extension://abc/popup.html', runScripts: 'outside-only', pretendToBeVisual: true });
const { window } = dom;
const doc = window.document;
const alerts = [];
Object.defineProperty(window, 'alert', { value: (m) => alerts.push(m), configurable: true, writable: true });
window.chrome = {
  runtime: {
    sendMessage: (m, cb) => {
      sentToBg.push(m);
      if (m.type === 'GET_MEMORY' && cb) cb({ data: {}, slots: [] });
      if (m.type === 'GET_STEP_COUNT' && cb) cb(0);
      if (m.type === 'GET_PLAN' && cb) cb({ plan: [], thinking: '', run: 1, total: 1 });
      return { catch() {} };
    },
    onMessage: { addListener: (fn) => { bgListener = fn; } },
    getURL: (p) => 'chrome-extension://abc/' + p,
  },
  storage: { local: {
    get: (keys, cb) => { const out = {}; (Array.isArray(keys) ? keys : [keys]).forEach(k => { if (k in store) out[k] = store[k]; }); cb(out); },
    set: (o) => { Object.assign(store, o); },
    remove: (k) => { delete store[k]; },
  }},
  tabs: { create: () => {}, query: (q, cb) => cb && cb([]) },
};
// no speech / media
window.SpeechRecognition = undefined;
window.webkitSpeechRecognition = undefined;
Object.defineProperty(window.navigator, 'mediaDevices', { value: { getUserMedia: () => Promise.reject(new Error('no')) }, configurable: true });

let loadErr = null;
try {
  window.eval(js);   // registers the DOMContentLoaded listener; jsdom fires the event on a later tick
} catch (e) { loadErr = e; }

setTimeout(() => {
  ok('popup.js loads without error', !loadErr);
  if (loadErr) { console.error(loadErr); console.log(`\n=== popup.js: ${pass} passed, ${fail} failed ===`); process.exit(1); }

  const providerSelect = doc.getElementById('provider-select');
  const modelSelect = doc.getElementById('model-select');
  const apiKey = doc.getElementById('api-key');
  const baseUrl = doc.getElementById('base-url');
  const goal = doc.getElementById('goal');
  const startBtn = doc.getElementById('start-btn');
  const keyHelp = doc.getElementById('key-help');
  const memoryView = doc.getElementById('memory-view');
  const planList = doc.getElementById('plan-list');

  // ===== default provider + suggested model =====
  ok('default provider = gemini', providerSelect.value === 'gemini');
  ok('suggested model = gemini-3.1-flash-lite', modelSelect.value === 'gemini-3.1-flash-lite');
  ok('gemini key-help points at AI Studio', keyHelp.href.includes('aistudio.google.com'));
  ok('key-help visible for gemini', keyHelp.style.display !== 'none');

  // ===== provider change: custom =====
  providerSelect.value = 'custom';
  providerSelect.dispatchEvent(new window.Event('change'));
  ok('custom shows base URL field', doc.getElementById('base-url-section').style.display !== 'none');
  ok('custom hides key-help', keyHelp.style.display === 'none');
  ok('custom persists selectedProvider', store.selectedProvider === 'custom');

  // ===== provider change: chrome-ai hides key =====
  providerSelect.value = 'chrome-ai';
  providerSelect.dispatchEvent(new window.Event('change'));
  ok('chrome-ai hides API key section', apiKey.closest('.section').style.display === 'none');

  // ===== provider change: groq key link =====
  providerSelect.value = 'groq';
  providerSelect.dispatchEvent(new window.Event('change'));
  ok('groq key-help points at groq console', keyHelp.href.includes('groq.com'));

  // ===== start validation =====
  providerSelect.value = 'gemini';
  providerSelect.dispatchEvent(new window.Event('change'));
  apiKey.value = '';
  goal.value = 'do a thing';
  alerts.length = 0; sentToBg.length = 0;
  startBtn.dispatchEvent(new window.Event('click'));
  ok('start with no key -> alert, no START_AGENT', alerts.length === 1 && !sentToBg.some(m => m.type === 'START_AGENT'));

  apiKey.value = 'AIzaTESTKEY';
  goal.value = '';
  alerts.length = 0; sentToBg.length = 0;
  startBtn.dispatchEvent(new window.Event('click'));
  ok('start with no goal -> alert', alerts.length === 1);

  apiKey.value = 'AIzaTESTKEY';
  goal.value = 'search for cats';
  alerts.length = 0; sentToBg.length = 0;
  startBtn.dispatchEvent(new window.Event('click'));
  const startMsg = sentToBg.find(m => m.type === 'START_AGENT');
  ok('valid start -> START_AGENT sent', !!startMsg);
  ok('START_AGENT payload has provider/model/goal', startMsg && startMsg.payload.provider === 'gemini' && startMsg.payload.model === 'gemini-3.1-flash-lite' && startMsg.payload.goal === 'search for cats');
  ok('key saved to storage', store.githubApiKey === 'AIzaTESTKEY');

  // ===== custom start needs base URL + model =====
  // stop first
  doc.getElementById('stop-btn').dispatchEvent(new window.Event('click'));
  providerSelect.value = 'custom';
  providerSelect.dispatchEvent(new window.Event('change'));
  apiKey.value = 'sk-or-test';
  baseUrl.value = '';
  doc.getElementById('custom-model').value = 'z-ai/glm-5.3-flash';
  goal.value = 'x';
  alerts.length = 0; sentToBg.length = 0;
  startBtn.dispatchEvent(new window.Event('click'));
  ok('custom with no base URL -> alert', alerts.length === 1 && /Base URL/i.test(alerts[0]));

  baseUrl.value = 'https://openrouter.ai/api/v1';
  alerts.length = 0; sentToBg.length = 0;
  startBtn.dispatchEvent(new window.Event('click'));
  const cm = sentToBg.find(m => m.type === 'START_AGENT');
  ok('custom valid -> START_AGENT with baseUrl + model', cm && cm.payload.baseUrl === 'https://openrouter.ai/api/v1' && cm.payload.model === 'z-ai/glm-5.3-flash');

  // ===== incoming messages render =====
  bgListener({ type: 'PLAN', payload: [{ n: 1, text: 'step one', done: true }, { n: 2, text: 'step two', done: false }] });
  ok('PLAN renders list items', planList.children.length === 2 && planList.children[0].classList.contains('done'));

  bgListener({ type: 'UPDATE_MEMORY', payload: { data: { leads: 'a\nb\nc' }, slots: [{ key: 'leads', desc: 'the leads' }, { key: 'summary', desc: 's' }] } });
  ok('UPDATE_MEMORY renders filled + empty', /● leads/.test(memoryView.textContent) && /○ summary/.test(memoryView.textContent));

  bgListener({ type: 'LOG', payload: { text: 'hello log', level: 'system' } });
  ok('LOG appends to log container', doc.getElementById('logs').textContent.includes('hello log'));

  bgListener({ type: 'HUMAN_NEEDED', reason: 'which one?' });
  ok('HUMAN_NEEDED shows banner + answer box', doc.getElementById('human-banner').style.display === 'flex');

  // resume with an answer
  doc.getElementById('human-answer').value = 'use the second';
  sentToBg.length = 0;
  doc.getElementById('resume-btn').dispatchEvent(new window.Event('click'));
  const rm = sentToBg.find(m => m.type === 'RESUME_AGENT');
  ok('Resume sends RESUME_AGENT with answer', rm && rm.answer === 'use the second');

  console.log(`\n=== popup.js: ${pass} passed, ${fail} failed ===`);
  process.exit(fail ? 1 : 0);
}, 250);
