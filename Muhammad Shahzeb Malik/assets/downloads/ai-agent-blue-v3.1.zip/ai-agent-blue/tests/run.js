// Runs all three suites in-process and reports a combined total.
const { execFileSync } = require('child_process');
const path = require('path');

const suites = ['test-bg.js', 'test-content.js', 'test-popup.js'];
let pass = 0, fail = 0, hardFail = false;

for (const s of suites) {
  let out;
  try {
    out = execFileSync(process.execPath, [path.join(__dirname, s)], { encoding: 'utf8' });
  } catch (e) {
    out = (e.stdout || '') + (e.stderr || '');
    hardFail = true;
  }
  process.stdout.write(out);
  pass += (out.match(/^PASS /gm) || []).length;
  fail += (out.match(/^FAIL /gm) || []).length;
}

console.log(`\n========================================`);
console.log(`TOTAL: ${pass} passed, ${fail} failed`);
console.log(`========================================`);
process.exit(fail > 0 || hardFail ? 1 : 0);
