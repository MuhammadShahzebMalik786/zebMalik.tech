// content.js tests via jsdom
const fs = require('fs');
const { JSDOM } = require('jsdom');

const src = fs.readFileSync(require('path').join(__dirname,'..','content.js'), 'utf8');

let pass = 0, fail = 0;
const ok = (n, c) => { console.log((c ? 'PASS ' : 'FAIL ') + n); c ? pass++ : fail++; };

function makeDoc(html) {
  const dom = new JSDOM(html, { url: 'https://example.com', pretendToBeVisual: true, runScripts: 'outside-only' });
  const { window } = dom;
  window.HTMLElement.prototype.scrollIntoView = () => {};
  window.scrollBy = () => {};
  window.scrollTo = () => {};
  window.PointerEvent = window.PointerEvent || window.MouseEvent;   // jsdom lacks PointerEvent
  // jsdom lacks layout: fake getBoundingClientRect so isElementVisible passes for our fixtures
  window.Element.prototype.getBoundingClientRect = function () {
    const hidden = this.closest('[data-hidden]') || this.style.display === 'none';
    if (hidden) return { width: 0, height: 0, top: 0, left: 0, bottom: 0, right: 0 };
    const w = parseInt(this.style.width) || 200;
    const h = parseInt(this.style.height) || 30;
    return { width: w, height: h, top: 10, left: 10, bottom: 10 + h, right: 10 + w };
  };
  Object.defineProperty(window.HTMLElement.prototype, 'innerText', {
    get() { return this.textContent; }, set(v) { this.textContent = v; }, configurable: true
  });
  window.getComputedStyle = () => ({ display: 'block', visibility: 'visible', opacity: '1' });
  let listener = null;
  window.chrome = { runtime: { onMessage: { addListener: (fn) => { listener = fn; } }, sendMessage: () => {} } };
  window.DataTransfer = window.DataTransfer || function () { this._d = {}; this.setData = (k, v) => this._d[k] = v; this.getData = (k) => this._d[k] || ''; };
  window.ClipboardEvent = window.ClipboardEvent || function (type, init) { const e = new window.Event(type, init); e.clipboardData = init && init.clipboardData; return e; };
  window.eval(src);
  return { window, doc: window.document, call: (msg) => new Promise((res) => listener(msg, {}, res)) };
}

(async () => {
  // ===== buildSimplifiedDOM: numbered list, whole page =====
  {
    const { call } = makeDoc(`<body>
      <h1>Big Heading Text Here That Is Long</h1>
      <button id="b1">Click Me</button>
      <a href="#">A link somewhere</a>
      <input type="text" placeholder="Type here">
      <div style="position:absolute;top:5000px"><button>Below the fold button</button></div>
      <script>var x = "this should never appear in snapshot";</script>
    </body>`);
    const r = await call({ type: 'EXTRACT_DOM' });
    ok('EXTRACT_DOM returns dom/url/title', r && typeof r.dom === 'string' && r.url.includes('example.com'));
    ok('snapshot numbers elements [1]', /\[1\]/.test(r.dom));
    ok('snapshot has the button', /Click Me/.test(r.dom));
    ok('snapshot includes below-the-fold element', /Below the fold button/.test(r.dom));
    ok('snapshot excludes <script> contents', !r.dom.includes('should never appear'));
  }

  // ===== buildSimplifiedDOM: dialog scoping =====
  {
    const { call } = makeDoc(`<body>
      <div><button>PAGE BUTTON OUTSIDE</button><p>lots of page text lorem ipsum dolor sit amet consectetur</p></div>
      <div role="dialog" aria-modal="true" style="width:600px;height:400px">
        <button>Modal Confirm Button</button>
      </div>
    </body>`);
    const r = await call({ type: 'EXTRACT_DOM' });
    ok('dialog marker present', r.dom.startsWith('[dialog]'));
    ok('dialog scope: modal button in', /Modal Confirm Button/.test(r.dom));
    ok('dialog scope: page button out', !/PAGE BUTTON OUTSIDE/.test(r.dom));
  }

  // ===== buildSimplifiedDOM: maxChars budget =====
  {
    const rows = Array.from({ length: 400 }, (_, i) => `<button>Button number ${i} with some padding text</button>`).join('');
    const { call } = makeDoc(`<body>${rows}</body>`);
    const small = await call({ type: 'EXTRACT_DOM', maxChars: 1000 });
    ok('maxChars budget respected', small.dom.length < 1400);
    ok('truncation marker shown', /TRUNCATED/.test(small.dom));
  }

  // ===== EXTRACT_MEMORY: chat container =====
  {
    const { call } = makeDoc(`<body>
      <div data-message-author-role="user">my question</div>
      <div data-message-author-role="assistant">Here is the assistant answer. It is reasonably long so it passes the length threshold easily.</div>
    </body>`);
    const r = await call({ type: 'EXECUTE_ACTION', payload: { action: 'EXTRACT_MEMORY', elementId: 0, key: 'x' } });
    ok('EXTRACT chat: success', r.success === true);
    ok('EXTRACT chat: got assistant text', /assistant answer/.test(r.extractedText));
    ok('EXTRACT chat: not the user msg', !/my question/.test(r.extractedText));
  }

  // ===== EXTRACT_MEMORY: job board (the regression we fixed) =====
  {
    const jobText = 'We are hiring a market research assistant. Duties: manual competitor price monitoring across Walmart and Home Depot, weekly reports, data entry into spreadsheets. '.repeat(6);
    const { call } = makeDoc(`<body>
      <div class="toast-message">Saved to your jobs</div>
      <div class="notification-message">3 new alerts</div>
      <main>
        <h1>Market Research Assistant</h1>
        <div id="jobDescriptionText">${jobText}</div>
      </main>
    </body>`);
    const r = await call({ type: 'EXECUTE_ACTION', payload: { action: 'EXTRACT_MEMORY', elementId: 0, key: 'lead' } });
    ok('EXTRACT job: success', r.success === true);
    ok('EXTRACT job: grabbed the description, not a toast', r.extractedText.length > 300 && /competitor price monitoring/.test(r.extractedText));
    ok('EXTRACT job: ignored the small *message* nodes', !/Saved to your jobs/.test(r.extractedText.slice(0, 50)));
  }

  // ===== EXTRACT_MEMORY: still-generating guard =====
  {
    const { call } = makeDoc(`<body>
      <button data-testid="stop-button">Stop</button>
      <div class="markdown">partial...</div>
    </body>`);
    const r = await call({ type: 'EXECUTE_ACTION', payload: { action: 'EXTRACT_MEMORY', elementId: 0, key: 'x' } });
    ok('EXTRACT: refuses while generating', r.success === false && /generating/i.test(r.message));
  }

  // ===== TYPE into a plain input =====
  {
    const { window, call } = makeDoc(`<body><input type="text" id="s"></body>`);
    // first snapshot so interactableElements is populated
    await call({ type: 'EXTRACT_DOM' });
    const doc = window.document;
    // find the id the snapshot assigned to the input
    const snap = (await call({ type: 'EXTRACT_DOM' })).dom;
    const m = snap.match(/\[(\d+)\] input/);
    const r = await call({ type: 'EXECUTE_ACTION', payload: { action: 'TYPE', elementId: Number(m[1]), text: 'hello world' } });
    ok('TYPE into input: success', r.success === true);
    ok('TYPE into input: value set', doc.getElementById('s').value === 'hello world');
  }

  // ===== TYPE into a non-input contenteditable (Illegal invocation guard) =====
  {
    const { window, call } = makeDoc(`<body><div id="ed" contenteditable="true"></div></body>`);
    await call({ type: 'EXTRACT_DOM' });
    const snap = (await call({ type: 'EXTRACT_DOM' })).dom;
    const m = snap.match(/\[(\d+)\] contenteditable/);
    ok('contenteditable is in snapshot', !!m);
    const r = await call({ type: 'EXECUTE_ACTION', payload: { action: 'TYPE', elementId: Number(m[1]), text: 'x'.repeat(50) } });
    ok('TYPE into contenteditable: no crash', r && typeof r.success === 'boolean');
    ok('TYPE into contenteditable: text landed', window.document.getElementById('ed').textContent.length >= 40);
  }

  // ===== SCROLL / CLICK don't throw =====
  {
    const { window, call } = makeDoc(`<body><button id="cb">Go</button></body>`);
    window.scrollBy = () => {};
    window.HTMLElement.prototype.scrollIntoView = () => {};
    await call({ type: 'EXTRACT_DOM' });
    const snap = (await call({ type: 'EXTRACT_DOM' })).dom;
    const bid = Number(snap.match(/\[(\d+)\] button/)[1]);
    let clicked = false;
    window.document.getElementById('cb').addEventListener('click', () => clicked = true);
    const rc = await call({ type: 'EXECUTE_ACTION', payload: { action: 'CLICK', elementId: bid } });
    await new Promise(r => setTimeout(r, 350));
    ok('CLICK dispatches a click', clicked === true);
    const rs = await call({ type: 'EXECUTE_ACTION', payload: { action: 'SCROLL', direction: 'down' } });
    ok('SCROLL: success', rs.success === true);
  }

  // ===== TYPE_FROM_MEMORY: full inject + verification =====
  {
    const { window, call } = makeDoc(`<body><div id="ed" contenteditable="true"></div></body>`);
    // make the synthetic paste event actually populate the field (like a real editor would)
    window.document.getElementById('ed').addEventListener('paste', function (e) {
      this.textContent = e.clipboardData.getData('text/plain');
    });
    await call({ type: 'EXTRACT_DOM' });
    const snap = (await call({ type: 'EXTRACT_DOM' })).dom;
    const eid = Number(snap.match(/\[(\d+)\] contenteditable/)[1]);
    const long = 'This is a long humanized paragraph. '.repeat(30);
    const r = await call({ type: 'EXECUTE_ACTION', payload: { action: 'TYPE_FROM_MEMORY', elementId: eid, memoryKey: 'k', resolvedText: long } });
    ok('TYPE_FROM_MEMORY: success', r.success === true);
    ok('TYPE_FROM_MEMORY: full text landed', window.document.getElementById('ed').textContent.length >= long.length * 0.9);
  }

  // ===== empty form fields stay in the snapshot (regression) =====
  {
    const { call } = makeDoc(`<body><textarea id="t"></textarea><select id="s"><option>a</option></select><button></button></body>`);
    const r = await call({ type: 'EXTRACT_DOM' });
    ok('empty textarea kept in snapshot', /\] textarea:/.test(r.dom));
    ok('empty select kept in snapshot', /\] select:/.test(r.dom));
  }

  // ===== TYPE_FROM_MEMORY: missing key -> FAILED =====
  {
    const { call } = makeDoc(`<body><input id="i"></body>`);
    await call({ type: 'EXTRACT_DOM' });
    const eid = Number((await call({ type: 'EXTRACT_DOM' })).dom.match(/\[(\d+)\] input/)[1]);
    const r = await call({ type: 'EXECUTE_ACTION', payload: { action: 'TYPE_FROM_MEMORY', elementId: eid, memoryKey: 'k' } });
    ok('TYPE_FROM_MEMORY: no resolvedText -> FAILED', r.success === false);
  }

  // ===== non-modal small dialog should NOT scope =====
  {
    const { call } = makeDoc(`<body>
      <div><button>MAIN PAGE ACTION</button><p>${'page content '.repeat(30)}</p></div>
      <div role="dialog" style="width:180px;height:90px"><button>tiny popover</button></div>
    </body>`);
    const r = await call({ type: 'EXTRACT_DOM' });
    ok('small non-modal dialog is NOT scoped', !r.dom.startsWith('[dialog]') && /MAIN PAGE ACTION/.test(r.dom));
  }

  console.log(`\n=== content.js: ${pass} passed, ${fail} failed ===`);
  process.exit(fail ? 1 : 0);
})().catch(e => { console.error('HARNESS ERROR', e); process.exit(2); });
