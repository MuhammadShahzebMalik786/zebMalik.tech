// Load background.js with globals stubbed, then unit-test the pure + near-pure functions.
const fs = require('fs');
const path = require('path').join(__dirname, '..', 'background.js');
let src = fs.readFileSync(path, 'utf8');

// ---- stubs ----
const logLines = [];
const sent = [];
const chrome = {
  runtime: {
    sendMessage: (m) => { sent.push(m); return { catch(){} }; },
    onMessage: { addListener(){} },
    lastError: null,
  },
  storage: { local: {
    get: (k, cb) => { if (cb) cb({}); return Promise.resolve({}); },
    set: () => ({ catch(){} }),
    remove: () => {},
  }},
  tabs: {
    query: async () => [{ id: 1, url: 'https://example.com' }],
    get: async (id) => ({ id, url: 'https://example.com' }),
    update: async () => ({}),
    create: async (o) => ({ id: 2, ...o }),
    remove: async () => {},
    sendMessage: (id, m, cb) => { if (cb) cb({ success: true, message: 'ok' }); },
    goBack: async () => {},
  },
  alarms: { create(){}, clear(){}, onAlarm: { addListener(){} } },
  scripting: { executeScript: async () => {} },
  sidePanel: { setPanelBehavior: () => ({ catch(){} }) },
};
let fetchImpl = async () => ({ ok: true, status: 200, json: async () => ({ candidates: [{ content: { parts: [{ text: '{}' }] } }] }), text: async () => '' });
const fetchStub = (...a) => fetchImpl(...a);

// Expose internals: append a return of the names we need.
const NAMES = ['parseJsonLoose','plannerModelFor','needsConfirmation','detectStuckLoop','elementLabel',
  'renderMemory','trimForNano','dispatchAction','callLLMModel','buildSystemPrompt','generatePlan',
  'getBuiltInLM','callChromeAI','handleDoneOrRepeat','applyResult'];
// also expose the mutable module state via getters/setters
src += `
;globalThis.__setState = (o) => { for (const k in o) { try { eval(k + ' = o[k]'); } catch(e){} } };
;globalThis.__getState = () => ({ agentMemory, actionHistory, memorySlots, autonomousMode, pendingAction, taskPlan, humanNotes, repeatsRemaining, initialRepeats, runNumber, stepCount });
;return { ${NAMES.join(',')} };
`;

const factory = new Function('chrome','LanguageModel','fetch','AbortController','self','globalThis', src);
const LM = undefined;
const api = factory(chrome, LM, fetchStub, global.AbortController || class { abort(){} get signal(){return{}} }, {}, globalThis);

// ---- test runner ----
let pass = 0, fail = 0;
const eq = (name, got, want) => {
  const ok = JSON.stringify(got) === JSON.stringify(want);
  console.log((ok ? 'PASS ' : 'FAIL ') + name + (ok ? '' : `\n   got:  ${JSON.stringify(got)}\n   want: ${JSON.stringify(want)}`));
  ok ? pass++ : fail++;
};
const ok = (name, cond) => { console.log((cond ? 'PASS ' : 'FAIL ') + name); cond ? pass++ : fail++; };

// ===== parseJsonLoose =====
eq('parseJsonLoose plain', api.parseJsonLoose('{"a":1}'), { a: 1 });
eq('parseJsonLoose fenced', api.parseJsonLoose('```json\n{"a":1}\n```'), { a: 1 });
eq('parseJsonLoose prose-wrapped', api.parseJsonLoose('Sure! {"action":"DONE","reason":"x"} done'), { action: 'DONE', reason: 'x' });
ok('parseJsonLoose throws on garbage', (() => { try { api.parseJsonLoose('not json at all'); return false; } catch { return true; } })());

// ===== plannerModelFor =====
eq('plannerModelFor passthrough gemini', api.plannerModelFor('gemini', 'gemini-3.1-flash-lite'), 'gemini-3.1-flash-lite');
eq('plannerModelFor passthrough custom', api.plannerModelFor('custom', 'z-ai/glm-5.3-flash'), 'z-ai/glm-5.3-flash');

// ===== detectStuckLoop =====
api.__setState = globalThis.__setState;
globalThis.__setState({ actionHistory: [] });
ok('detectStuckLoop empty -> false', api.detectStuckLoop() === false);
globalThis.__setState({ actionHistory: [
  {action:'CLICK',elementId:5},{action:'SCROLL'},{action:'CLICK',elementId:5},{action:'CLICK',elementId:5}
]});
ok('detectStuckLoop 3-of-4 same -> true', api.detectStuckLoop() === true);
globalThis.__setState({ actionHistory: [
  {action:'CLICK',elementId:1},{action:'CLICK',elementId:2},{action:'CLICK',elementId:3},{action:'SCROLL'}
]});
ok('detectStuckLoop varied -> false', api.detectStuckLoop() === false);
globalThis.__setState({ actionHistory: [
  {action:'NAVIGATE'},{action:'NAVIGATE'},{action:'NAVIGATE'}
]});
ok('detectStuckLoop 3 NAVIGATE -> true', api.detectStuckLoop() === true);

// ===== elementLabel =====
const dom = '[3] input[text]: "Search"\n[12] button: "Post"\n[45] a: "How to delete files"';
eq('elementLabel found', api.elementLabel({ dom }, 12), 'Post');
eq('elementLabel missing', api.elementLabel({ dom }, 99), '');
eq('elementLabel null id', api.elementLabel({ dom }, null), '');

// ===== needsConfirmation =====
globalThis.__setState({ autonomousMode: false, pendingAction: null });
ok('confirm: CLICK "Post" -> true', api.needsConfirmation({ action:'CLICK', elementId:12, reason:'publish' }, { dom, url:'https://x.com' }) === true);
ok('confirm: search submit on google -> false', api.needsConfirmation({ action:'TYPE', elementId:3, submit:true, reason:'search' }, { dom:'[3] input[text]: "Search"', url:'https://google.com' }) === false);
ok('confirm: TYPE no submit -> false', api.needsConfirmation({ action:'TYPE', elementId:3, submit:false, reason:'x' }, { dom, url:'https://x.com' }) === false);
ok('confirm: empty label on sensitive site -> true', api.needsConfirmation({ action:'CLICK', elementId:999, reason:'click it' }, { dom, url:'https://mail.google.com' }) === true);
ok('confirm: CLOSE_TABS all -> true', api.needsConfirmation({ action:'CLOSE_TABS', which:'all', reason:'x' }, { dom, url:'https://x.com' }) === true);
ok('confirm: CLOSE_TABS duplicates -> false', api.needsConfirmation({ action:'CLOSE_TABS', which:'duplicates', reason:'x' }, { dom, url:'https://x.com' }) === false);
globalThis.__setState({ autonomousMode: true });
ok('confirm: autonomous mode -> false', api.needsConfirmation({ action:'CLICK', elementId:12, reason:'publish' }, { dom, url:'https://x.com' }) === false);
globalThis.__setState({ autonomousMode: false });

// ===== renderMemory =====
globalThis.__setState({ memorySlots: [{key:'notion_pricing',desc:'Notion tiers'},{key:'summary',desc:'the summary'}], agentMemory: { notion_pricing: 'Free: unlimited pages. Paid: $8/mo. Standout: databases.' } });
const mem = api.renderMemory();
ok('renderMemory shows filled slot with [x]', /\[x\] notion_pricing \(\d+ chars\)/.test(mem));
ok('renderMemory shows empty slot with [ ]', /\[ \] summary/.test(mem) && /EMPTY/.test(mem));
ok('renderMemory does not dump full value', !mem.includes('Standout: databases.') || mem.length < 400);
globalThis.__setState({ memorySlots: [], agentMemory: {} });
ok('renderMemory empty', /empty/i.test(api.renderMemory()));

// ===== trimForNano =====
ok('trimForNano short passthrough', api.trimForNano('hello', 100) === 'hello');
const big = 'x'.repeat(5000);
const trimmed = api.trimForNano(big, 1000);
ok('trimForNano respects budget', trimmed.length <= 1050);
ok('trimForNano keeps head+tail', trimmed.startsWith('x') && trimmed.endsWith('x') && trimmed.includes('trimmed'));

// ===== dispatchAction: SAVE_MEMORY validation =====
(async () => {
  globalThis.__setState({ agentMemory: {}, autonomousMode: true });
  let r = await api.dispatchAction({ action:'SAVE_MEMORY', key:'lead', value: 'x'.repeat(900) }, 1);
  ok('SAVE_MEMORY 900 chars now accepted', r.status === 'SUCCESS');
  r = await api.dispatchAction({ action:'SAVE_MEMORY', key:'lead', value: 'y'.repeat(60), append:true }, 1);
  ok('SAVE_MEMORY append works', r.status === 'SUCCESS' && globalThis.__getState().agentMemory.lead.includes('y'.repeat(60)) && globalThis.__getState().agentMemory.lead.includes('x'.repeat(900)));
  r = await api.dispatchAction({ action:'SAVE_MEMORY', key:'huge', value: 'z'.repeat(5000) }, 1);
  ok('SAVE_MEMORY 5000 chars rejected', r.status === 'FAILED');

  // ===== dispatchAction: unknown action =====
  r = await api.dispatchAction({ action:'FROBNICATE', reason:'x' }, 1);
  ok('dispatchAction unknown -> FAILED', r.status === 'FAILED');

  // ===== dispatchAction: DONE / WAIT =====
  r = await api.dispatchAction({ action:'DONE', reason:'x' }, 1);
  ok('dispatchAction DONE -> {done:true}', r.done === true);
  r = await api.dispatchAction({ action:'WAIT', seconds: 8 }, 1);
  ok('dispatchAction WAIT -> delay', r.status === 'SUCCESS' && r.delay === 8000);
  r = await api.dispatchAction({ action:'WAIT', seconds: 999 }, 1);
  ok('dispatchAction WAIT clamps to 60s', r.delay === 60000);

  // ===== dispatchAction: HUMAN_NEEDED autonomous skip =====
  globalThis.__setState({ autonomousMode: true });
  r = await api.dispatchAction({ action:'HUMAN_NEEDED', reason:'is this the right one?' }, 1);
  ok('HUMAN_NEEDED (question) skipped in autonomous', r.status === 'SUCCESS' && /AUTONOMOUS/.test(r.feedback || ''));
  r = await api.dispatchAction({ action:'HUMAN_NEEDED', reason:'CAPTCHA detected, solve it' }, 1);
  ok('HUMAN_NEEDED (CAPTCHA) still pauses in autonomous', r.pause === true);
  globalThis.__setState({ autonomousMode: false });
  r = await api.dispatchAction({ action:'HUMAN_NEEDED', reason:'pick one' }, 1);
  ok('HUMAN_NEEDED pauses when not autonomous', r.pause === true);

  // ===== callLLMModel: action validation =====
  fetchImpl = async () => ({ ok: true, status: 200, text: async () => '',
    json: async () => ({ candidates: [{ content: { parts: [{ text: 'I think I should click something' }] } }] }) });
  try {
    await api.callLLMModel('k', 'gemini', 'gemini-3.1-flash-lite', 'goal', { dom: '[1] button: "x"', url: 'https://x.com', title: 't' });
    ok('callLLMModel throws on prose (no action)', false);
  } catch (e) { ok('callLLMModel throws on prose (no action)', /parse|action/i.test(e.message)); }

  fetchImpl = async () => ({ ok: true, status: 200, text: async () => '',
    json: async () => ({ candidates: [{ content: { parts: [{ text: '{"think":"ok","reason":"go"}' }] } }] }) });
  try {
    await api.callLLMModel('k', 'gemini', 'gemini-3.1-flash-lite', 'goal', { dom: '[1] button: "x"', url: 'https://x.com', title: 't' });
    ok('callLLMModel throws on JSON missing action', false);
  } catch (e) { ok('callLLMModel throws on JSON missing action', /action/i.test(e.message)); }

  fetchImpl = async () => ({ ok: true, status: 200, text: async () => '',
    json: async () => ({ candidates: [{ content: { parts: [{ text: '{"think":"ok","action":"click","elementId":1,"reason":"go"}' }] } }] }) });
  const a = await api.callLLMModel('k', 'gemini', 'gemini-3.1-flash-lite', 'goal', { dom: '[1] button: "x"', url: 'https://x.com', title: 't' });
  ok('callLLMModel uppercases action', a.action === 'CLICK');

  // ===== buildSystemPrompt sanity =====
  globalThis.__setState({ taskPlan: [{n:1,text:'do a',done:false}], memorySlots: [{key:'x',desc:'d'}], agentMemory: {}, humanNotes: ['answer: use option B'], autonomousMode: true });
  const sp = api.buildSystemPrompt('my goal', { dom: '[1] button: "Go"', url: 'https://x.com', title: 'T' });
  ok('prompt includes goal', sp.includes('my goal'));
  ok('prompt includes plan', sp.includes('1. do a'));
  ok('prompt includes human answer', sp.includes('use option B'));
  ok('prompt includes autonomous note', /AUTONOMOUS MODE IS ON/.test(sp));
  ok('prompt includes MEMORY section', sp.includes('MEMORY'));
  ok('prompt includes CLOSE_TABS action', sp.includes('CLOSE_TABS'));
  ok('prompt includes SAVE_MEMORY append guidance', /append/.test(sp));

  console.log(`\n=== background.js: ${pass} passed, ${fail} failed ===`);
  process.exit(fail ? 1 : 0);
})();
